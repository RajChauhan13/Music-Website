// To add more song, just copy the following code and paste inside the array

//   {
//     name: "Here is the music name",
//     artist: "Here is the artist name",
//     img: "image name here - remember img must be in .jpg formate and it's inside the images folder of this project folder",
//     src: "music name here - remember img must be in .mp3 formate and it's inside the songs folder of this project folder"
//   }

//paste it inside the array as more as you want music then you don't need to do any other thing

let allMusic = [
  {
    name: "Despacito",
    artist: "Luis Fonsi - ft. Daddy Yankee",
    img: "image-1",
    src: "music-1"
  },
  {
    name: "Fight Back",
    artist: "NEFFEX",
    img: "music-2",
    src: "music-2"
  },
  {
    name: "Shape of You",
    artist: "Ed Sheeran",
    img: "music-3",
    src: "music-3"
  },
  {
    name: "Tere Vaste",
    artist: "Varun Jain",
    img: "music-4",
    src: "music-4"
  },
  {
    name: "Khairiyat",
    artist: "Arijit Singh",
    img: "music-5",
    src: "music-5"
  },
  {
    name: "Jehda Nasha",
    artist: "Amar Jalal",
    img: "music-6",
    src: "music-6"
  },
  {
    name: "Aashiqui Aa Gayi",
    artist: "Arijit Singh",
    img: "music-7",
    src: "music-7"
  },
  // like this paste it and remember to give comma after ending of this bracket }
  // {
  //   name: "Here is the music name",
  //   artist: "Here is the artist name",
  //   img: "image name here - remember img must be in .jpg formate and it's inside the images folder of this project folder",
  //   src: "music name here - remember img must be in .mp3 formate and it's inside the songs folder of this project folder"
  // }
];