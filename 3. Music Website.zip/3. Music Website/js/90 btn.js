function VENOM() {
    var x = document.getElementById("song-sec");

    if(x.style.display === "inline-block") {
        x.style.display = "none"
    }

    else{
        x.style.display = "inline-block"
    }
}