function VENOM2() {
    var x = document.getElementById("song-sec-2");

    if(x.style.display === "inline-block") {
        x.style.display = "none"
    }

    else{
        x.style.display = "inline-block"
    }
}