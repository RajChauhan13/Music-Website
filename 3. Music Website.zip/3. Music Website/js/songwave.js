
        function PLAY() {
                    var x = document.getElementById("center");
        
                    if(x.style.visibility === "visible") {
                        x.style.visibility = "collapse"
                    }
        
                    else{
                        x.style.visibility = "visible"
                    }
                }
        